Task 2
--------------------------

1. Add a float field named "qty on order" inside the Product Variant Form View. Default Value of the field will be 1.0.
2. Add a field in sales order named "Total Capacity".
3. In Sale Order Line add a field named "Max. Qty Allowed".
4. Based on the selection of the Product Variant in the order line the value of the field max. qty should be filled with the value defined in that product variant field named qty on order.
5. Add a button before the total block named Calculate the total Capacity. On clicking the button, it should give you the sum of the Max. Qty Allowed field
   values and should be shown in the field named Total Capacity in sales order.

Note: "Max. Qty Allowed" field will be read-only in the sale order line.
