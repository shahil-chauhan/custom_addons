1. Create a new module.
2. Add a cron to print list of open sales orders (not in locked or sale_order state)
3. Set next execution date of cron to 10:00 pm through code (data file).
