Create a New Model Named 'tracking.order'. Add the following fields:

1) Sales Order Ref(many2one with sales.order)
2) User Name (many2one with res.users)
• Add a Menu in backend under Sales --> Configuration.