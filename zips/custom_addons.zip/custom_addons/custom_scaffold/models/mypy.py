from odoo import api, fields, models
from odoo.tools.translate import _


class DocumenterItem(models.Model):
    _name = "docu.item"
