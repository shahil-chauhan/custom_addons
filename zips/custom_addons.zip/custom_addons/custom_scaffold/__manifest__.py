# -*- coding: utf-8 -*-

{
    "name": " ",
    "summary": """ """,
    "description": """ """,
    "author": "Yash Shah",
    "website": "https://google.com",
    # for the full list
    "category": " ",
    "version": "14.0.1.0.0",
    # any module necessary for this one to work correctly
    "depends": [],
    # always loaded
    "data": [
        "security/ir.model.access.csv",
    ],
    "installable": True,
    "application": True,
    "auto_install": False,
    "sequence": 1,
}
