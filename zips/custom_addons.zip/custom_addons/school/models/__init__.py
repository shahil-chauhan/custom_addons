from . import school, student
# from . import res_partner, school, student
