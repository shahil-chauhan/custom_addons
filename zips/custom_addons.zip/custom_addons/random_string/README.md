Task 2
--------------------------

Add a button in product and product variant view which generates random string.