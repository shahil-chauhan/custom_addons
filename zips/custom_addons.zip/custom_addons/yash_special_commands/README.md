Task for many2many or one2many fields create,edit,delete.

1)Place one button sale.order form view [name of button- update M2M]. 
2)Place one custom field name custom_partner_ids many2many on sale order after name 
3)Click on update M2M button change in field custom_partner_ids like
[(6,0,list)]
[(5,)]
[(4,id)]...etc