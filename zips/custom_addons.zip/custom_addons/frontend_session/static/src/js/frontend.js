odoo.define('frontend_session.frontend', function (require) {
"use strict";

    //Document ready
    $(document).ready(function() {

        console.log('----------------***Frontend JS***----------------')

    });


});