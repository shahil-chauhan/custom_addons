from . import college, my_settings
