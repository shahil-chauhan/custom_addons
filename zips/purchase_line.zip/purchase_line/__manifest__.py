{
    "name": "Purchase order line",
    "summary": """POL related information""",
    "description": """""",
    "author": "Patel Akash",
    "website": "https://www.aktivsoftware.com/",
    "category": "Construction",
    "version": "14.0.1.0.0",
    "depends": [
        "purchase",
    ],
    "data": [
        'views/purchase_order_line_views.xml',
    ],
    "installable": True,
    "application": True,
    "auto_install": False,
}
