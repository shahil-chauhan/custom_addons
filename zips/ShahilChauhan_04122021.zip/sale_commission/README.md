Sale Commission
------------------------------------

Odoo Version : Odoo 14.0 Community

Installation
-------------------------------------
Install the Application => Apps -> Sale Commission

Project Functionality
---------------------------------------------

Calculate the commission on a product in the sale order line based on the commission in the sales order.