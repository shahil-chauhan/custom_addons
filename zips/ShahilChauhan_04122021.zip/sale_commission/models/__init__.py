# -*- coding: utf-8 -*-

from . import res_partner, sale_order
