from . import docu_item
from . import docu_tags
from . import docu_version
from . import ir_model
