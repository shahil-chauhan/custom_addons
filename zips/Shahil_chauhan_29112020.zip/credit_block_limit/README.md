Customer Credit or Blocking Limit
------------------------------------

Odoo Version : Odoo 14.0 Community

Project Functionality
---------------------------------------------

A module to add the customer credit and blocking limits for Sale Order/Quotation creation. If the customers Limit has
been exceeded then a mail will be sent to the customer.