# -*- coding: utf-8 -*-

from . import res_config_settings, res_partner, sale_order
