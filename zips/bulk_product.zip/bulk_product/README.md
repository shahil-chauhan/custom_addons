Bulk Products
---------------

The Bulk products module is use to add products in sale order line by selecting dropdown.
In website side, the bulk module created from the website, and also res partner created from the website.
At website you need to sign.