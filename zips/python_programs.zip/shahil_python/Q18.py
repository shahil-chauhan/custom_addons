# Please write a program to shuffle and print the list [3,6,7,8]

import random

lst = [3, 6, 7, 8]

random.shuffle(lst)

print(lst)
